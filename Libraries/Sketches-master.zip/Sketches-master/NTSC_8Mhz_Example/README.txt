
This is a sketch that demonstrates TV output at 8mhz using a 16mhz Arduino board.

http://tmrh20.blogspot.com