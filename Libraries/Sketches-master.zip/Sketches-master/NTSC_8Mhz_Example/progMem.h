#include <avr/pgmspace.h>
#ifndef PROGMEM_H
#define PROGMEM_H

extern const unsigned char ascii[128][7];

//extern const unsigned char *asciiTable[128];
#endif
